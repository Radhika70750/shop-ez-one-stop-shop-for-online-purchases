const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

const products = [
  { id: 1, name: 'Product A', price: 100 },
  { id: 2, name: 'Product B', price: 200 }
];

app.get('/api/products', (req, res) => {
  res.json(products);
});

app.post('/api/cart', (req, res) => {
  const cart = req.body;
  res.json({ message: 'Cart received', cart });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});